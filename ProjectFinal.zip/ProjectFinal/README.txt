# Projet_Developpement_Web
Projet session été 2023

# Documentation du Site Web KidsGames

## Développeurs
- Nom du développeur 1 : Norbert Tabaronyaduri - Contribution : Gestion de plusieurs niveaux du jeu
- Nom du développeur 2 : Christian Charles Ignace Ndione - Contribution : Création de la structure de la base de données
- Nom du développeur 3 : Karim Kabbadj - Contribution : Création de comptes utilisateur ou inscription (Sign-Up) 
- Nom du développeur 4 : Mohamed-Reda Kabbadj - Contribution : Connexion à un compte utilisateur existant (Sign-In)
- Nom du développeur 5 : Jorge Cermeno Zea - Contribution : Création et mise en place du compte GitHub
- Nom du développeur 6 : Alexandre Ionescu - Contribution : Creation de la structure des page web à afficher (ex: head, header, nav, footer)
  

## Date de publication
[26-07-2023]

## Fonctionnalités du Site Web
- Fonctionnalité 1 : Gérer la création automatique d'une base de données
- Fonctionnalité 2 : Créer des utilisateurs dans la base de données qui peuvent utiliser le jeu
- Fonctionnalité 3 : Se connecter pour utiliser le jeu
- Fonctionnalité 4 : Exécuter un jeu de six niveaux.

## Fonctionnement du jeu
Le jeu KidsGames comporte plusieurs niveaux passionnants. Chaque niveau présente des défis uniques et le joueur doit atteindre un objectif spécifique pour passer au niveau suivant. Le joueur dispose d'un nombre de vies limité et doit les gérer judicieusement pour éviter de perdre la partie. Plus le joueur progresse dans les niveaux, plus les défis deviennent difficiles.

## Informations techniques
- Langage de programmation : php, java, html, wampserver
- Système de gestion de base de données : MySQL Version: 8.0.31
- Version du langage de programmation : PhpMyAdmin 5.2.0 


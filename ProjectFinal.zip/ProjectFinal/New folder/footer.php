<!-- footer.php -->
<footer>
    &copy; <?php echo date('Y'); ?> Group 4.
</footer>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Notre Jeu</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <?php include 'header.php'; ?>
    <?php include 'nav.php'; ?>

    <div class="content">
        <h1>Bienvenue dans Notre Jeu</h1>
        <!-- Contenu du jeu à afficher ici -->
    </div>

    <?php include 'footer.php'; ?>
</body>
</html>

<!-- nav.php -->
<nav>
    <div class="button-container">
        <a href="index.php" class="button">Home</a>
        <a href="../Signin/php/signin.php" class="button">Sign-In</a>
        <a href="../register/php/register.php" class="button">Sign-Up</a>
    </div>
</nav>
<!-- header.php -->
<header>
    <h1>Kid's Game</h1>
</header>
<?php
session_start();

$db = new PDO('mysql:host=localhost;dbname=kidsGames;charset=utf8', 'root', '');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $req = $db->prepare('SELECT player.userName, authenticator.passCode FROM player 
    INNER JOIN authenticator ON player.registrationOrder = authenticator.registrationOrder 
    WHERE player.userName = :username');
    $req->execute(array(
        'username' => $username));
    $resultat = $req->fetch();

    $isPasswordCorrect = password_verify($password, $resultat['passCode']);

    if (!$resultat)
    {
        echo 'Désolé, le nom d\'utilisateur ou le mot de passe est incorrect!';
    }
    else
    {
        if ($isPasswordCorrect) {
            $_SESSION['username'] = $username;
            $_SESSION['last_activity'] = time(); /*Pour faire la mise de la derniere activite*/
            header('Location: game.php');
        }
        else {
            echo 'Désolé, le nom d\'utilisateur ou le mot de passe est incorrect!';
        }
    }
}

/*pour verifier si la session est active depuis 15min*/
if (isset($_SESSION['username']) && isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > 900) {
  session_unset();      
  session_destroy();   
  header('Location: index.php');  /*r'envoie a la page d'acceuil*/
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Connexion</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 300px;
            padding: 16px;
            background-color: #9370DB; /*Couleur de fond en mauve si tu veux la changer tu peux*/ 
            margin: 0 auto;
            margin-top: 50px;
            border: 1px solid black;
            border-radius: 4px;
        }
        label {
            color: blue;
        }
        input[type="text"], input[type="password"] {
            width: 100%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
        }
        button {
            background-color: red;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }
        .cancelbtn {
            background-color: blue;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 100%;
        }
        .psw {
            float: right;
        }
    </style>
</head>
<body>
<h2 style="text-align:center;">Connexion</h2>
<form action="login.php" method="post">
  <div class="container">
    <label for="uname"><b>Nom d'utilisateur</b></label>
    <input type="text" placeholder="Entrez votre nom d'utilisateur" name="username" required>

    <label for="psw"><b>Mot de passe</b></label>
    <input type="password" placeholder="Entrez votre mot de passe" name="password" required>

    <button type="submit">Se Connecter</button>
    <label>
      <input type="checkbox" checked="checked" name="remember"> Se souvenir de moi
    </label>
  </div>

  <div class="container" style="background-color:#f1f1f1">
    <button type="button" class="cancelbtn">Annuler</button>
    <span class="psw">Mot de passe <a href="#">oublié?</a></span>
  </div>
</form>
</body>
</html>

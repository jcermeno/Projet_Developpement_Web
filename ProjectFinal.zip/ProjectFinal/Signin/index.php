<!DOCTYPE html>
<html>
<head>
    <title>Welcome to Kids Game</title>
    <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
    <div class="navbar">
        <a href="../index.php">Home</a>
        <a href="../Signin/php/signin.php">Sign In</a>
        <a href="../register/php/register.php">Register</a>
    </div>

    <h1>Welcome to Kids Game!</h1>
    <p>Please sign in to continue or register if you don't have an account.</p>
</body>
</html>

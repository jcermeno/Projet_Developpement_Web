<?php $isSignInPage = true; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Kid's Game</title>
    <style>
        .container {
            margin: 50px auto; 
            max-width: 800px;
            background-color: #F8D9C5;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #FFEDD2;
            padding: 50px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        form label {
            display: block;
            margin-bottom: 10px;
        }

        form input[type="text"],
        form input[type="password"] {
            width: 100%;
            max-width: 780px; 
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 15px;
        }

        form input[type="submit"] {
            background-color: #FCA311;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
        }

        form input[type="submit"]:hover {
            background-color: #FFD166;
        }

        p {
            text-align: center;
            margin-top: 20px;
        }

        a {
            color: #FCA311;
        }
    </style>

</head>
<body>
    <?php session_start(); ?>
    <div class="container">
        <?php include '../../includes/header.php'; ?>
        <?php include '../../includes/nav.php'; ?>
       
    
    
    <form action="signin_check.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <input type="submit" value="Sign In">
    </form>
    <p>Not registered yet? <a href="../../register/php/register.php">Sign Up</a></p>
    <?php
    
    if (isset($_SESSION['error'])) {
        echo "<p>" . $_SESSION['error'] . "</p>";
        echo "<p><a href='password_reset.php'>Forgot your password? Reset it.</a></p>";
        unset($_SESSION['error']);
    }
    if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 5)) {
        session_unset();
        session_destroy();
    }
    ?>
    <script>
        setTimeout(function() {
            window.location.href = "signout.php";
        }, 150000);
    </script>
    <?php include '../../includes/footer.php'; ?>
    </div>
</body>
</html>

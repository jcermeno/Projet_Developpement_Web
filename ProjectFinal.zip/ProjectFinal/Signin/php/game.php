<?php
session_start();
if (!isset($_SESSION['username'])) {
    header("Location: signin.php");
    exit;
}

/*if (isset($_SESSION['username'])) {
    header("Location: ../../Game/myGame.php");
    exit;
}*/


if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 900)) {
    
    session_unset();     
    session_destroy();   
    header("Location: signin.php");
    exit;
}
$_SESSION['last_activity'] = time(); 

?>
<!DOCTYPE html>
<html>
<head>
    <title>Game</title>
    <style>
        .container {
            margin: 50px auto; 
            max-width: 800px;
            background-color: #F8D9C5;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #FFEDD2;
            padding: 50px;
            text-align: center;
        }

    </style>
    <!--<link rel="stylesheet" type="text/css" href="style.css">-->
</head>
<body>
    <div class="container">
    <?php include '../../includes/header.php'; ?>
    <h1>Welcome to the Game, <?php echo $_SESSION['username']; ?>!</h1>
    <?php include '../../Game/myGame.php'  ?><br>
    <a href="../../index.php">Logout</a>
   

    <script>
        setTimeout(function() {
            window.location.href = "signout.php";
        }, 900000);
    </script>
    <?php include '../../includes/footer.php'; ?>
    </div>
</body>
</html>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kid's Game</title>
    <style>
        .game-container {
        margin: 50px auto; 
        max-width: 600px;
        background-color: #F8D9C5;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }
    </style>
</head>
<body>
    <div class="game-container">
        <?php include '../../includes/header.php'; ?>
        <?php
            session_start();

            echo "<style>
            body {
                font-family: Arial, sans-serif;
                line-height: 1.6;
                max-width: 600px;
                margin: 0 auto;
                padding: 20px;
                background-color: #FFEDD2;
            }
            h1 {
                color: #333;
            }
            h2 {
                color: #666;
                margin-top: 20px;
            }
            p {
                color: #444;
            }
            form {
                margin-top: 10px;
            }
            input[type='text'],
            input[type='number'] {
                padding: 5px;
                font-size: 14px;
                border: 1px solid #ccc;
                border-radius: 3px;
                margin-bottom: 5px;
            }
            input[type='submit'] {
                padding: 8px 12px;
                font-size: 16px;
                background-color: #FCA311;
                color: #fff;
                border: none;
                border-radius: 3px;
                cursor: pointer;
                margin-bottom: 5px;

            }
            input[type='submit']:hover {
                background-color: #FFD166;
            }
            </style>";

            function generateRandomLetters($count)
            {
                $letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
                return substr(str_shuffle($letters), 0, $count);
            }

            function generateRandomNumbers($count)
            {
                $numbers = array();
                for ($i = 0; $i < $count; $i++) {
                    $numbers[] = mt_rand(0, 100);
                }
                return implode(', ', $numbers);
            }

            function resetGameData()
            {
                $_SESSION['game_data'] = array(
                    generateRandomLetters(6),
                    generateRandomLetters(6),
                    array_map('intval', explode(', ', generateRandomNumbers(6))),
                    array_map('intval', explode(', ', generateRandomNumbers(6))),
                    generateRandomLetters(6),
                    array_map('intval', explode(', ', generateRandomNumbers(6))),
                );
                $_SESSION['current_level'] = 1;
                $_SESSION['lives'] = 6;
            }

            function displayCongratulatoryMessage()
            {
                echo "<h2>Congratulations! You completed all levels!</h2>";
                echo "<form action='myGame.php' method='post'>
                        <input type='submit' name='play_again' value='Play Again'>
                        <input type='submit' name='quit_game' value='Quit Game'>
                    </form>";

                if (isset($_POST['play_again'])) {
                    resetGameData();
                    $_SESSION['current_level'] = 1; // Reset the current level to 1
                    header("Location: myGame.php");
                    exit();
                }

                if (isset($_POST['quit_game'])) {
                    session_destroy();
                    header("Location: myGame.php");
                    exit();
                }
            }

            function checkSmallestAndLargestNumber($original, $submitted)
            {
                $smallestNumber = min($original);
                $largestNumber = max($original);
                $submittedSmallest = intval($submitted['smallest_number']);
                $submittedLargest = intval($submitted['largest_number']);

                if ($submittedSmallest === $smallestNumber && $submittedLargest === $largestNumber) {
                    return "Correct – You identified the smallest and largest numbers correctly";
                } else {
                    return "Incorrect – Your identification of the smallest and largest numbers is wrong";
                }
            }

            function checkFirstAndLastLetter($original, $submitted)
            {
                $firstLetter = $original[0];
                $lastLetter = $original[strlen($original) - 1]; // Get the last letter
                $submittedFirst = $submitted['first_letter'];
                $submittedLast = $submitted['last_letter'];

                if ($submittedFirst === $firstLetter && $submittedLast === $lastLetter) {
                    return "Correct – You identified the first and last letters correctly";
                } else {
                    return "Incorrect – You did not identify the first and last letters correctly";
                }
            }

            function checkOrder($original, $submitted, $ascending = true)
            {
                $expectedOrder = $ascending ? 'ascending' : 'descending';
                $sortedOriginal = $original;
                $sortedSubmitted = $submitted;

                if (is_array($original)) {
                    $ascending ? sort($sortedOriginal) : rsort($sortedOriginal);
                } else {
                    $sortedOriginal = str_split($original);
                    $ascending ? sort($sortedOriginal) : rsort($sortedOriginal);
                }

                if (is_array($submitted)) {
                    $ascending ? sort($sortedSubmitted) : rsort($sortedSubmitted);
                } else {
                    $sortedSubmitted = str_split($submitted);
                    $ascending ? sort($sortedSubmitted) : rsort($sortedSubmitted);
                }

                $originalString = is_array($sortedOriginal) ? implode('', $sortedOriginal) : $sortedOriginal;
                $submittedString = is_array($sortedSubmitted) ? implode('', $sortedSubmitted) : $sortedSubmitted;

                if ($submittedString === $originalString) {
                    return "Correct – Your numbers/letters were correctly ordered in $expectedOrder order";
                } else {
                    return "Incorrect – Your numbers/letters were not correctly arranged in $expectedOrder order";
                }
            }

            function displayLevel($level, $content, $lives)
            {
                // Check if the current level is beyond the defined levels
                if ($level > count($_SESSION['game_data'])) {
                    // Display "Game Over" message after level 6
                    echo "<h2>Game Over!</h2>";

                    // Show options to play again or quit
                    echo "<form action='myGame.php' method='post'>
                            <input type='submit' name='play_again' value='Play Again'>
                            <input type='submit' name='quit_game' value='Quit Game'>
                        </form>";
                    
                    return;
                }

                echo "<h2>Level $level Result:</h2>";

                switch ($level) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                        $submitted = array_map('trim', $_POST['input']);
                        $result = checkOrder($content, $submitted, $level % 2 === 0);
                        break;
                    case 5:
                        $submitted = $_POST['input'];
                        $result = checkFirstAndLastLetter($content, $submitted);
                        break;
                    case 6:
                        $submitted = $_POST['input'];
                        $result = checkSmallestAndLargestNumber($content, $submitted);
                        break;
                    default:
                        echo "<p>Level $level does not exist.</p>";
                        echo "<form action='myGame.php' method='post'>
                                <input type='submit' name='abandon_game' value='Play Again'>
                            </form>";
                        resetGameData();
                        break;
                }

                echo "<p>$result</p>";

                if (strpos($result, "Correct") !== false) {
                    if ($level === 6) {
                        displayCongratulatoryMessage(); // Display the congratulatory message and options after level 6
                    } else {
                        $nextLevel = $level + 1;
                        $_SESSION['current_level'] = $nextLevel;
                        echo "<form action='myGame.php' method='post'>
                                <input type='submit' value='Go to next level'>
                            </form>";
                    }
                } else {
                    $lives--;
                    $_SESSION['lives'] = $lives;

                    if ($lives > 0) {
                        echo "<form action='myGame.php?level=$level&lives=$lives' method='post'>
                                <input type='submit' value='Try again'>
                            </form>";
                    } else {
                        echo "<h2>Game Over!</h2>";
                        echo "<form action='myGame.php' method='post'>
                                <input type='submit' name='play_again' value='Play Again'>
                            </form>";
                        resetGameData(); // Move the resetGameData() call here to reset the game data after game over
                    }
                }
            }

            if (isset($_POST['abandon_game'])) {
                resetGameData();
                header("Location: myGame.php");
                exit();
            }

            // Check for the play_again button and reset the game data before displaying the first level
            if (isset($_POST['play_again'])) {
                resetGameData();
                $_SESSION['current_level'] = 1; // Reset the current level to 1
                header("Location: myGame.php");
                exit();
            }

            // Check if the session is not set or the current level exceeds the number of defined levels, and reset the game data
            if (!isset($_SESSION['game_data']) || $_SESSION['current_level'] > count($_SESSION['game_data'])) {
                resetGameData();
                $_SESSION['current_level'] = 1; // Reset the current level to 1
            }

            // Display the current level
            $currentLevel = $_SESSION['current_level'];
            $lives = $_SESSION['lives'];
            $levelContent = $_SESSION['game_data'][$currentLevel - 1];

            if (!isset($_SESSION['game_data']) || !isset($_SESSION['current_level']) || !isset($_SESSION['lives'])) {
                resetGameData();
            }

            $levels = array(
                'Arrange 6 letters in ascending order',
                'Arrange 6 letters in descending order',
                'Arrange 6 numbers in ascending order',
                'Arrange 6 numbers in descending order',
                'Identify the first letter and the last letter of a set of 6 letters',
                'Identify the smallest and largest number of a set of 6 numbers'
            );

            $currentLevel = $_SESSION['current_level'];
            $lives = $_SESSION['lives'];
            $levelContent = $_SESSION['game_data'][$currentLevel - 1];

            if (isset($_POST['submit'])) {
                displayLevel($currentLevel, $levelContent, $lives);
                unset($_POST['submit']);
            } else {
                echo "<h1>Game Level $currentLevel: {$levels[$currentLevel - 1]}</h1>";
                echo "<p>Remaining Lives: $lives</p>";

                switch ($currentLevel) {
                    case 3:
                    case 4:
                        $levelContentDisplay = implode(', ', $levelContent);
                        echo "<p>Numbers: $levelContentDisplay</p>";
                        echo "<form action='myGame.php?level=$currentLevel&lives=$lives' method='post'>";
                        for ($i = 0; $i < count($levelContent); $i++) {
                            echo "<label for='input_$i'>Input $i:</label>
                                <input type='number' name='input[$i]' id='input_$i' required>
                                <br>";
                        }
                        echo "<input type='submit' name='submit' value='Submit'>
                            </form>";
                        break;
                    case 5:
                        $levelContentDisplay = $levelContent;
                        echo "<p>Letters: $levelContentDisplay</p>";
                        echo "<form action='myGame.php?level=$currentLevel&lives=$lives' method='post'>";
                        echo "<label for='first_letter'>First Letter:</label>
                            <input type='text' name='input[first_letter]' id='first_letter' maxlength='1' required>
                            <br>";
                        echo "<label for='last_letter'>Last Letter:</label>
                            <input type='text' name='input[last_letter]' id='last_letter' maxlength='1' required>
                            <br>";
                        echo "<input type='submit' name='submit' value='Submit'>
                            </form>";
                        break;
                    case 6:
                        $levelContentDisplay = implode(', ', $levelContent);
                        echo "<p>Numbers: $levelContentDisplay</p>";
                        echo "<form action='myGame.php?level=$currentLevel&lives=$lives' method='post'>";
                        echo "<label for='smallest_number'>Smallest Number:</label>
                            <input type='number' name='input[smallest_number]' id='smallest_number' required>
                            <br>";
                        echo "<label for='largest_number'>Largest Number:</label>
                            <input type='number' name='input[largest_number]' id='largest_number' required>
                            <br>";
                        echo "<input type='submit' name='submit' value='Submit'>
                            </form>";
                        break;
                    default:
                        $instructions = ($currentLevel % 2 === 0) ? 'Descending' : 'Ascending';
                        $levelContentDisplay = implode(', ', str_split($levelContent));
                        echo "<p>Instructions: Arrange these numbers/letters in $instructions order.</p>";
                        echo "<p>Numbers/Letters: $levelContentDisplay</p>";
                        echo "<form action='myGame.php?level=$currentLevel&lives=$lives' method='post'>";
                        for ($i = 0; $i < strlen($levelContent); $i++) {
                            echo "<label for='input_$i'>Input $i:</label>
                                <input type='text' name='input[$i]' id='input_$i' maxlength='1' required>
                                <br>";
                        }
                        echo "<input type='submit' name='submit' value='Submit'>
                            </form>";
                        break;
                }
            }

            echo "<form action='myGame.php' method='post'>
                    <input type='submit' name='abandon_game' value='Abandon Game'>
                </form>";

        ?>
         <?php include '../../includes/footer.php'; ?>
    </div>
</body>
</html>


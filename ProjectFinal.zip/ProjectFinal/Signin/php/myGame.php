
<?php

include '../../includes/header.php';
echo "<style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
        }
        h2 {
            color: #666;
            margin-top: 20px;
        }
        p {
            color: #444;
        }
        form {
            margin-top: 10px;
        }
        input[type='text'],
        input[type='number'] {
            padding: 5px;
            font-size: 14px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-bottom: 5px;
        }
        input[type='submit'] {
            padding: 8px 12px;
            font-size: 16px;
            background-color: #070D12;
            color: #fff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }
        input[type='submit']:hover {
            background-color: #8B9198;
        }
      </style>";

      
      session_start();
      
      // Function to generate random letters from 'a' to 'z'
      function generateRandomLetters($count)
      {
          $letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
          return substr(str_shuffle($letters), 0, $count);
      }
      
      // Function to generate random numbers
      function generateRandomNumbers($count)
      {
          $numbers = array();
          for ($i = 0; $i < $count; $i++) {
              $numbers[] = mt_rand(0, 100); // Add a random number between 0 and 100 to the array
          }
          return implode(', ', $numbers);
      }
      
      // Function to check if the submitted numbers/letters are in correct order
      function checkOrder($original, $submitted, $ascending = true)
      {
          $expectedOrder = $ascending ? 'ascending' : 'descending';
      
          if ($ascending) {
              if (is_array($original)) {
                  sort($original);
              } else {
                  $original = str_split($original);
                  sort($original);
              }
      
              if (is_array($submitted)) {
                  sort($submitted);
              } else {
                  $submitted = str_split($submitted);
                  sort($submitted);
              }
          } else {
              if (is_array($original)) {
                  rsort($original);
              } else {
                  $original = str_split($original);
                  rsort($original);
              }
      
              if (is_array($submitted)) {
                  rsort($submitted);
              } else {
                  $submitted = str_split($submitted);
                  rsort($submitted);
              }
          }
      
          $originalString = is_array($original) ? implode('', $original) : $original;
          $submittedString = is_array($submitted) ? implode('', $submitted) : $submitted;
      
          if ($submittedString === $originalString) {
              return "Correct – Your numbers/letters were correctly ordered in $expectedOrder order";
          } elseif ($submittedString === $original) {
              return "Incorrect – Your numbers/letters were not correctly arranged in $expectedOrder order";
          } else {
              return "Incorrect – Some of your numbers/letters are different from ours.";
          }
      }
      
      // Function to display a message for each game level result
      function displayResult($original, $submitted, $level, &$lives)
      {
          echo "<h2>Level $level Result:</h2>";
      
          if ($level < 5) {
              $result = checkOrder($original, $submitted, $level % 2 === 0);
              echo "<p>$result</p>";
      
              if (strpos($result, "Correct") !== false) {
                  $nextLevel = $level + 1;
                  $_SESSION['current_level'] = $nextLevel; // Update the current level
                  echo "<form action='myGame.php?level=$nextLevel&lives=$lives' method='post'>
                          <input type='submit' value='Go to next level'>
                        </form>";
              } else {
                  $lives--;
                  $_SESSION['lives'] = $lives; // Update the remaining lives
      
                  if ($lives > 0) {
                      echo "<form action='myGame.php?level=$level&lives=$lives' method='post'>
                              <input type='submit' value='Try again'>
                            </form>";
                  } else {
                      echo "<h2>Game Over!</h2>";
                      echo "<form action='myGame.php' method='post'>
                              <input type='submit' value='Play Again'>
                            </form>";
                  }
              }
          }
          if ($level === 5) {
              $firstLetter = trim($submitted['first_letter']);
              $lastLetter = trim($submitted['last_letter']);
      
              if ($firstLetter === $original[0] && $lastLetter === $original[5]) {
                  echo "<p>Correct – You identified the first and last letters correctly.</p>";
                  $nextLevel = $level + 1;
                  $_SESSION['current_level'] = $nextLevel;
                  echo "<form action='myGame.php?level=$nextLevel&lives=$lives' method='post'>
                          <input type='submit' value='Go to next level'>
                        </form>";
              } else {
                  echo "<p>Incorrect – Your identification of the first and last letters is wrong.</p>";
                  $lives--;
                  $_SESSION['lives'] = $lives;
      
                  if ($lives > 0) {
                      echo "<form action='myGame.php?level=$level&lives=$lives' method='post'>
                              <input type='submit' value='Try again'>
                            </form>";
                  } else {
                      echo "<h2>Game Over!</h2>";
                      echo "<form action='myGame.php' method='post'>
                              <input type='submit' value='Play Again'>
                            </form>";
                  }
              }
          }
      
          // Level 6: Identify the smallest and largest number of a set of 6 numbers
          else if ($level === 6) {
              $smallestNumber = intval($submitted['smallest_number']);
              $largestNumber = intval($submitted['largest_number']);
      
              if ($smallestNumber === min($original) && $largestNumber === max($original)) {
                  echo "<p>Correct – You identified the smallest and largest numbers correctly.</p>";
                  echo "<h2>Congratulations! You have completed the game successfully.</h2>";
                  echo "<form action='myGame.php' method='post'>
                          <input type='submit' value='Play Again'>
                        </form>";
              } else {
                  echo "<p>Incorrect – Your identification of the smallest and largest numbers is wrong.</p>";
                  $lives--;
                  $_SESSION['lives'] = $lives;
      
                  if ($lives > 0) {
                      echo "<form action='myGame.php?level=$level&lives=$lives' method='post'>
                              <input type='submit' value='Try again'>
                            </form>";
                  } else {
                      echo "<h2>Game Over!</h2>";
                      echo "<form action='myGame.php' method='post'>
                              <input type='submit' value='Play Again'>
                            </form>";
                  }
              }
          }
      
      
          unset($_POST['submit']); // Clear the form submission
      }
      
      // Function to display a message for the "Arrange 6 numbers in ascending order" level
      function displayNumbersAscendingLevel($original, $submitted, $level, &$lives)
      {
          echo "<h2>Level $level Result:</h2>";
      
          sort($original); // Sort the original array in ascending order
      
          // Convert the submitted values to an array of integers
          $submittedNumbers = array_map('intval', $submitted);
      
          // Check if the submitted array matches the original array
          if ($submittedNumbers === $original) {
              echo "<p>Correct – Your numbers were arranged in ascending order</p>";
      
              $nextLevel = $level + 1;
              $_SESSION['current_level'] = $nextLevel; // Update the current level
      
              echo "<form action='myGame.php?level=$nextLevel&lives=$lives' method='post'>
                      <input type='submit' value='Go to next level'>
                    </form>";
          } else {
              echo "<p>Incorrect – Your numbers were not arranged in ascending order</p>";
              $lives--;
              $_SESSION['lives'] = $lives; // Update the remaining lives
      
              if ($lives > 0) {
                  echo "<form action='myGame.php?level=$level&lives=$lives' method='post'>
                          <input type='submit' value='Try again'>
                        </form>";
              } else {
                  echo "<h2>Game Over!</h2>";
                  echo "<form action='myGame.php' method='post'>
                          <input type='submit' value='Play Again'>
                        </form>";
              }
          }
      }
      
      // Function to display a message for the "Arrange 6 numbers in descending order" level
      function displayNumbersDescendingLevel($original, $submitted, $level, &$lives)
      {
          echo "<h2>Level $level Result:</h2>";
      
          rsort($original); // Sort the original array in descending order
      
          // Convert the submitted values to an array of integers
          $submittedNumbers = array_map('intval', $submitted);
      
          // Check if the submitted array matches the original array
          if ($submittedNumbers === $original) {
              echo "<p>Correct – Your numbers were arranged in descending order</p>";
      
              $nextLevel = $level + 1;
              $_SESSION['current_level'] = $nextLevel; // Update the current level
      
              echo "<form action='myGame.php?level=$nextLevel&lives=$lives' method='post'>
                      <input type='submit' value='Go to next level'>
                    </form>";
          } else {
              echo "<p>Incorrect – Your numbers were not arranged in descending order</p>";
              $lives--;
              $_SESSION['lives'] = $lives; // Update the remaining lives
      
              if ($lives > 0) {
                  echo "<form action='myGame.php?level=$level&lives=$lives' method='post'>
                          <input type='submit' value='Try again'>
                        </form>";
              } else {
                  echo "<h2>Game Over!</h2>";
                  echo "<form action='myGame.php' method='post'>
                          <input type='submit' value='Play Again'>
                        </form>";
              }
          }
      }
      
      // Function to display a message for the "Identify the first and last letter of a set of 6 letters" level
      function displayFirstAndLastLetterLevel($original, $submitted, $level, &$lives)
      {
          echo "<h2>Level $level Result:</h2>";
      
          // Get the first and last letters of the original array
          $firstLetter = $original[0];
          $lastLetter = end($original);
      
          // Check if the submitted letters match the original letters
          if ($submitted[0] === $firstLetter && $submitted[1] === $lastLetter) {
              echo "<p>Correct – You identified the first and last letters correctly</p>";
      
              $nextLevel = $level + 1;
              $_SESSION['current_level'] = $nextLevel; // Update the current level
      
              echo "<form action='myGame.php?level=$nextLevel&lives=$lives' method='post'>
                      <input type='submit' value='Go to next level'>
                    </form>";
          } else {
              echo "<p>Incorrect – You did not identify the first and last letters correctly</p>";
              $lives--;
              $_SESSION['lives'] = $lives; // Update the remaining lives
      
              if ($lives > 0) {
                  echo "<form action='myGame.php?level=$level&lives=$lives' method='post'>
                          <input type='submit' value='Try again'>
                        </form>";
              } else {
                  echo "<h2>Game Over!</h2>";
                  echo "<form action='myGame.php' method='post'>
                          <input type='submit' value='Play Again'>
                        </form>";
              }
          }
      }
      
      // Function to display a message for the "Identify the smallest and largest number of a set of 6 numbers" level
      function displaySmallestAndLargestNumberLevel($original, $submitted, $level, &$lives)
      {
          echo "<h2>Level $level Result:</h2>";
      
          // Get the smallest and largest numbers of the original array
          $smallestNumber = min($original);
          $largestNumber = max($original);
      
          // Check if the submitted numbers match the original numbers
          if ($submitted[0] == $smallestNumber && $submitted[1] == $largestNumber) {
              echo "<p>Correct – You identified the smallest and largest numbers correctly</p>";
      
              $nextLevel = $level + 1;
              $_SESSION['current_level'] = $nextLevel; // Update the current level
      
              echo "<form action='myGame.php?level=$nextLevel&lives=$lives' method='post'>
                      <input type='submit' value='Go to next level'>
                    </form>";
          } else {
              echo "<p>Incorrect – You did not identify the smallest and largest numbers correctly</p>";
              $lives--;
              $_SESSION['lives'] = $lives; // Update the remaining lives
      
              if ($lives > 0) {
                  echo "<form action='myGame.php?level=$level&lives=$lives' method='post'>
                          <input type='submit' value='Try again'>
                        </form>";
              } else {
                  echo "<h2>Game Over!</h2>";
                  echo "<form action='myGame.php' method='post'>
                          <input type='submit' value='Play Again'>
                        </form>";
              }
          }
      }
      function resetGameData()
      {
          $_SESSION['game_data'] = array(
              generateRandomLetters(6),
              generateRandomLetters(6),
              array_map('intval', explode(', ', generateRandomNumbers(6))),
              array_map('intval', explode(', ', generateRandomNumbers(6))),
              generateRandomLetters(6),
              array_map('intval', explode(', ', generateRandomNumbers(6))),
          );
          $_SESSION['current_level'] = 1;
          $_SESSION['lives'] = 6;
      }
      // Check if the "Abandon Game" button was clicked
      if (isset($_POST['abandon_game'])) {
          resetGameData();
          header("Location: myGame.php");
          exit();
      }
      
      // Initialize the game data on the first load
      if (!isset($_SESSION['game_data'])) {
          resetGameData();
      }
      
      
      // Initialize the game data on the first load
      if (!isset($_SESSION['game_data'])) {
          $_SESSION['game_data'] = array(
              generateRandomLetters(6),
              generateRandomLetters(6),
              array_map('intval', explode(', ', generateRandomNumbers(6))), // Convert the string to an array of integers
              array_map('intval', explode(', ', generateRandomNumbers(6))), // Convert the string to an array of integers
              generateRandomLetters(6),
              array_map('intval', explode(', ', generateRandomNumbers(6))), // Convert the string to an array of integers (Level 6)
          );
          $_SESSION['current_level'] = 1;
          $_SESSION['lives'] = 6;
      }
      
      
      $levels = array(
          'Arrange 6 letters in ascending order',
          'Arrange 6 letters in descending order',
          'Arrange 6 numbers in ascending order',
          'Arrange 6 numbers in descending order',
          'Identify the first letter and the last letter of a set of 6 letters',
          'Identify the smallest and largest number of a set of 6 numbers'
      );
      
      $currentLevel = $_SESSION['current_level'];
      $lives = $_SESSION['lives'];
      $levelContent = $_SESSION['game_data'][$currentLevel - 1];
      
      if (isset($_POST['submit'])) {
          // Handle form submissions
          if ($currentLevel === 3) {
              $submitted = array_map('intval', $_POST['input']); // Convert submitted values to an array of integers
              $original = $_SESSION['game_data'][$currentLevel - 1];
              displayNumbersAscendingLevel($original, $submitted, $currentLevel, $lives);
          } else if ($currentLevel === 4) {
              $submitted = array_map('intval', $_POST['input']); // Convert submitted values to an array of integers
              $original = $_SESSION['game_data'][$currentLevel - 1];
              displayNumbersDescendingLevel($original, $submitted, $currentLevel, $lives);
          } else {
              // Handle other game levels with the existing displayResult function
              $submitted = array_map('trim', $_POST['input']);
              $original = $_SESSION['game_data'][$currentLevel - 1];
              displayResult($original, $submitted, $currentLevel, $lives);
          }
      
          unset($_POST['submit']); // Clear the form submission
      } else {
          // Display the current level form
          echo "<h1>Game Level $currentLevel: {$levels[$currentLevel - 1]}</h1>";
          echo "<p>Remaining Lives: $lives</p>";
      
          if ($currentLevel === 3 || $currentLevel === 4) {
              $levelContent = $_SESSION['game_data'][$currentLevel - 1];
              $instructions = ($currentLevel === 3) ? 'Ascending' : 'Descending';
              echo "<p>Numbers: " . implode(', ', $levelContent) . "</p>";
              echo "<form action='myGame.php?level=$currentLevel&lives=$lives' method='post'>";
              for ($i = 0; $i < count($levelContent); $i++) {
                  echo "<label for='input_$i'>Input $i:</label>
                        <input type='number' name='input[]' id='input_$i' required>
                        <br>";
              }
              echo "<input type='submit' name='submit' value='Submit'>
                    </form>";
          } else if ($currentLevel === 5) {
              $levelContent = $_SESSION['game_data'][$currentLevel - 1];
              echo "<p>Letters: $levelContent</p>";
              echo "<form action='myGame.php?level=$currentLevel&lives=$lives' method='post'>";
              echo "<label for='first_letter'>First Letter:</label>
                    <input type='text' name='input[first_letter]' id='first_letter' maxlength='1' required>
                    <br>";
              echo "<label for='last_letter'>Last Letter:</label>
                    <input type='text' name='input[last_letter]' id='last_letter' maxlength='1' required>
                    <br>";
              echo "<input type='submit' name='submit' value='Submit'>
                    </form>";
          } else if ($currentLevel === 6) {
              $levelContent = $_SESSION['game_data'][$currentLevel - 1];
              echo "<p>Numbers: " . implode(', ', $levelContent) . "</p>";
              echo "<form action='myGame.php?level=$currentLevel&lives=$lives' method='post'>";
              echo "<label for='smallest_number'>Smallest Number:</label>
                    <input type='number' name='input[smallest_number]' id='smallest_number' required>
                    <br>";
              echo "<label for='largest_number'>Largest Number:</label>
                    <input type='number' name='input[largest_number]' id='largest_number' required>
                    <br>";
              echo "<input type='submit' name='submit' value='Submit'>
                    </form>";
          } else {
              // Display other game levels using the existing displayResult function
              $instructions = ($currentLevel % 2 === 0) ? 'Descending' : 'Ascending';
              $levelContentDisplay = implode(', ', str_split($levelContent));
      
              echo "<p>Instructions: Arrange these numbers/letters in $instructions order.</p>";
              echo "<p>Numbers/Letters: $levelContentDisplay</p>";
              echo "<form action='myGame.php?level=$currentLevel&lives=$lives' method='post'>";
              for ($i = 0; $i < strlen($levelContent); $i++) {
                  echo "<label for='input_$i'>Input $i:</label>
                        <input type='text' name='input[]' id='input_$i' maxlength='1' required>
                        <br>";
              }
              echo "<input type='submit' name='submit' value='Submit'>
                    </form>";
          }
      }
      // Display the "Abandon Game" button
      echo "<form action='myGame.php' method='post'>
              <input type='submit' name='abandon_game' value='Abandon Game'>
            </form>";
      
      // Handling the game level progression and life decrement
      if ($currentLevel > 1 && isset($_GET['lives'])) {
          $_SESSION['lives'] = (int)$_GET['lives'];
          $_SESSION['lives']--;
      }
      
     
      include '../../includes/footer.php';  
      
?>

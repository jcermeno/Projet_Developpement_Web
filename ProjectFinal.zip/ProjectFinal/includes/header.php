  <!-- header.php -->
  <header style="background-color: #333; color: #fff; padding: 10px; text-align: center;">
        <h1 style="margin: 0; color: #fff;">Kid's Game</h1>
    </header>
  <!-- header.php -->
  <header style="background-color: #F15A24; color: #fff; padding: 10px; text-align: center; font-size: 24px;">
        <h1 style="margin: 0; color: #fff;">Kid's Game</h1>
    </header>
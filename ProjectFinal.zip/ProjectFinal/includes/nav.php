    <!-- nav.php -->
    <nav style="background-color: #FCA311; color: #fff; padding: 5px; text-align: center;">
        <div class="button-container">
            <a href="../../index.php" class="button" style= " display: inline-block; margin-right: 10px; padding: 10px 20px; background-color: #FCA311; color: #fff; text-decoration: none; border-radius: 20px; font-size: 16px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);">Home</a>
            <?php if (!isset($isSignInPage) || $isSignInPage === false): ?>
            <a href="../../Signin/php/signin.php" class="button" style=" display: inline-block; margin-right: 10px; padding: 10px 20px; background-color: #FCA311; color: #fff; text-decoration: none; border-radius: 20px; font-size: 16px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);">Sign-In</a>
            <?php endif; ?>
            
            <?php //if (!isset($hideHistoriqueButton) || !$hideHistoriqueButton): ?>
            <!--<a href="../../ProjectFinal/historique.php" class="button" style=" display: inline-block; margin-right: 10px; padding: 10px 20px; background-color: #FCA311; color: #fff; text-decoration: none; border-radius: 20px; font-size: 16px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);">Historique</a>-->
            <?php //endif; ?>
            <?php if (!isset($hideSignUpButton) || !$hideSignUpButton): ?>
            <a href="../../register/php/register.php" class="button" style=" display: inline-block; margin-right: 10px; padding: 10px 20px; background-color: #FCA311; color: #fff; text-decoration: none; border-radius: 20px; font-size: 16px; box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);">Sign-Up</a>
            <?php endif; ?>

        </div>
    </nav> 
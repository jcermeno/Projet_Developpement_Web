    <!-- nav.php -->
    <nav style="background-color: #444; color: #fff; padding: 5px;">
        <div class="button-container">
            <a href="../index.php" class="button" style="margin-right: 10px; padding: 10px 20px; background-color: #8B9198; color: #fff; text-decoration: none; border-radius: 5px;">Home</a>
            <a href="../../ProjectFinal/Signin/php/signin.php" class="button" style="margin-right: 10px; padding: 10px 20px; background-color: #8B9198; color: #fff; text-decoration: none; border-radius: 5px;">Sign-In</a>
            <a href="../../ProjectFinal/register/php/register.php" class="button" style="margin-right: 10px; padding: 10px 20px; background-color: #8B9198; color: #fff; text-decoration: none; border-radius: 5px;">Sign-Up</a>
            <a href="../../ProjectFinal/historique.php" class="button" style="margin-right: 10px; padding: 10px 20px; background-color: #8B9198; color: #fff; text-decoration: none; border-radius: 5px;">Historique</a>
        </div>
    </nav>
<!-- footer.php -->
<footer style="background-color: #333; color: #fff; text-align: center; padding: 10px;">
    &copy; <?php echo date('Y'); ?> Group 4.
</footer>
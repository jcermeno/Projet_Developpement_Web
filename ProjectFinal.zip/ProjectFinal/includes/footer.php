<!-- footer.php -->
<footer style="background-color: #F15A24; color: #fff; text-align: center; padding: 10px;">
    &copy; <?php echo date('Y'); ?> Group 4.
</footer>
<!DOCTYPE html>
<html>
<head>
    <title>Registration</title>
    <style>
        .container {
            margin: 50px auto; 
            max-width: 800px;
            background-color: #F8D9C5;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #FFEDD2;
            padding: 50px;
            text-align: center;
        }

        
        form label {
            display: block;
            text-align: center;
            margin-bottom: 5px;
        }




        form input[type="text"], form input[type="password"] {
            width: 90%;
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }

        form button {
            padding: 10px 20px;
            border: none;
            background-color: #007BFF;
            color: #ffffff;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
        }

        form button:hover {
            background-color: #0056b3;
        }

        a {
            color: #FCA311;
        }
    </style>
   
</head>
<body>

    <div class="container">

        <?php 
            session_start();
            $hideSignInButton = true;
            $hideSignUpButton = true;
        ?>

        <?php include '../../includes/header.php'; ?>
        <?php include '../../includes/nav.php'; ?>

            
        <form action="register_check.php" method="post">
            <h1>Registration</h1>
            <label for="fName">First Name:</label>
            <input type="text" id="fName" name="fName" required>
            <label for="lName">Last Name:</label>
            <input type="text" id="lName" name="lName" required>
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <input type="submit" value="Register">
            <p>Already registered? <a href="../../Signin/php/signin.php">Sign In</a></p>
        </form>

        <?php
            
            if (isset($_SESSION['error'])) {
                echo "<p class='error-message'>" . $_SESSION['error'] . "</p>";
                unset($_SESSION['error']);
            }
            
            if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 900)) {
                session_unset();
                session_destroy();
            }
        ?>
        
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

        <script src="validate.js"></script>

        <?php include '../../includes/footer.php'; ?>
    </div>
</body>
</html>

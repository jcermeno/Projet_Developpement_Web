<!DOCTYPE html>
<html>
<head>
    <title>Jeux pour enfants</title>
    <style>
        .container {
            margin: 50px auto; 
            max-width: 600px;
            background-color: #F8D9C5;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #FFEDD2;
            padding: 50px;
            text-align: center;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        p {
            text-align: center;
            margin-top: 20px;
        }

        a {
            color: #FCA311;
            text-align: center;
        }

    </style>
</head>
<body>
    <div class="container">
        <?php include '../includes/header.php'; ?>
        <?php include '../includes/nav2.php'; ?>
        <h1>Bienvenue sur Jeux pour enfants !</h1>
        <p>Découvrez des jeux amusants et stimulants pour les enfants !</p>
        <a href="../register/php/register.php">Inscrivez-vous maintenant !</a>
        <p>Déjà membre ? <a href="../Signin/php/signin.php">Connectez-vous</a></p>
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>

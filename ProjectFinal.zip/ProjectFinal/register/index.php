<!DOCTYPE html>
<html>
<head>
    <title>Jeux pour enfants</title>
    <link rel="stylesheet" type="text/css" href=".././css/styles.css">
</head>
<body>
    <h1>Bienvenue sur Jeux pour enfants !</h1>
    <p>Découvrez des jeux amusants et stimulants pour les enfants !</p>
    <a href="../register/php/register.php">Inscrivez-vous maintenant !</a>
    <p>Déjà membre ? <a href="../Signin/php/signin.php">Connectez-vous</a></p>
</body>
</html>

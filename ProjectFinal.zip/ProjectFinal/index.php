<?php
if (isset($_SESSION['username'])) {
    header("Location: ../Game/myGame.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kid's Game</title>
    <style>

        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }       

        header {
            background-color: #333;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        header h1{
            margin: 0;
        }

        nav {
            background-color: #444;
            color: #fff;
            padding: 5px;
        }

        .content {
            padding: 20px;
            text-align: center;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 50px;
        }

        
        .button-container {
            display: flex;
        }

        .button-container a {
            display: inline-block;
            margin-right: 10px;
            padding: 10px 20px;
            background-color: #8B9198;
            color: #ffffff;
            text-decoration: none;
            border-radius: 5px;
        }

        .button-container a:hover {
            background-color: #070D12;
        }
    </style>
</head>
<body>
    <!-- header.php -->
    <header>
        <h1>Kid's Game</h1>
    </header>

    <!-- nav.php -->
    <nav>
        <div class="button-container">
            <a href="index.php" class="button">Home</a>
            <a href="../ProjectFinal/Signin/php/signin.php" class="button">Sign-In</a>
            <a href="../ProjectFinal/register/php/register.php" class="button">Sign-Up</a>
            <a href="../ProjectFinal/includes/historique.php" class="button">Historique</a>
        </div>
    </nav>

    <div class="content">
        <h1>Bienvenue dans Notre Jeu</h1>
        <!-- Contenu du jeu à afficher ici -->
    </div>

    <!-- footer.php -->
    <footer>
        &copy; <?php echo date('Y'); ?> Group 4.
    </footer>
</body>
</html>

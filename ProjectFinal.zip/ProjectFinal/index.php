<?php
    session_start();

   

  

    function createDatabaseIfNeeded() {
        include 'db/Base_donnees_Projet_Final.php';
         $_SESSION['db_installed'] = true;
        // Ajouter un echo pour vérifier que $_SESSION['db_installed'] est correctement défini.
        echo "Database installed successfully.";
    }
    
    if (!isset($_SESSION['db_installed'])) {
        // Appeler la fonction pour créer la base de données
        createDatabaseIfNeeded();
    }

    // Redirige l'utilisateur vers la page de jeu s'il s'est connecté avec succès.
    if (isset($_SESSION['submit_login'])) {
        header("Location: ../Game/myGame.php");
        exit;
    }


?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Kid's Game</title>
    <style>
        
        .container {
            margin: 50px auto; 
            max-width: 600px;
            background-color: #F8D9C5;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
        }

        body {
            font-family: 'Comic Sans MS', cursive, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #FFEDD2;
        }       

        header {
            background-color:  #F15A24;
            color: #fff;
            padding: 10px;
            text-align: center;
            font-size: 24px; 
        }

        header h1{
            margin: 0;
        }

        nav {
            background-color: #FCA311;
            color: #fff;
            padding: 10px;
            text-align: center;
        }

        .content {
            padding: 20px;
            text-align: center;
        }

        .content h1 {
            color: #FCA311;
            font-size: 36px; 
            font-weight: bold; 
        }

        footer {
            background-color: #F15A24;
            color: #fff;
            text-align: center;
            padding: 10px;
        }
        
        body {
            font-family: Arial, sans-serif;
            background-color: #FFEDD2;
            padding: 50px;
        }

        
        .button-container {
            display: flex;
        }

        .button-container a {
            display: inline-block;
            margin-right: 10px;
            padding: 10px 20px;
            background-color: #FCA311;
            color: #ffffff;
            text-decoration: none;
            border-radius: 20px;
            font-size: 16px; 
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .button-container a:hover {
            background-color: #FFD166;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- header.php -->
        <header>
            <h1>Kid's Game</h1>
        </header>

        <!-- nav.php -->
        <nav>
            <div class="button-container">
                <a href="index.php" class="button">Home</a>
                <a href="../ProjectFinal/Signin/php/signin.php" class="button">Sign-In</a>
                <a href="../ProjectFinal/register/php/register.php" class="button">Sign-Up</a>
                <a href="../ProjectFinal/includes/historique.php" class="button">Historique</a>
              
            </div>
        </nav>

        <div class="content">
            <h1>Bienvenue dans Notre Jeu</h1>
            
        </div>

        <!-- footer.php -->
        <footer>
            &copy; <?php echo date('Y'); ?> Group 4.
         </footer>
    </div>
</body>
</html>
